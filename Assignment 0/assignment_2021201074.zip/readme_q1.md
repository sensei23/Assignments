# Problem
Given 2 images. Create a (big) T-shaped
hole in the first image, and fill it with details from the second image. 

<br>

# Solution
Since the image loaded using opencv stores it in numpy array, we simply replace the values at positions to different image's values, by simple value assignment in arrays.

<br>

# Learnings
-   learnt how to use the opencv python library
- how to load a image in it
- use of numpy arrays
- applications of various formats that we can open the image in the library